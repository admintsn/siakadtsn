<?php

namespace App\Http\Requests\Auth;

use App\Models\User;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        // return [
        //     'email' => ['required', 'string', 'email'],
        //     'password' => ['required', 'string'],
        // ];

        return [
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ];
    }

    /**
     * Attempt to authenticate the request's credentials.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function authenticate(): void
    {

        $is_active = User::where('username', $this->username)->first();

        switch (true) {

            case ($is_active->is_active === '1'):

                $this->ensureIsNotRateLimited();
                $user = User::where('username', $this->username)->first();
                // dd($this->username);
                //original
                // if (! Auth::attempt($this->only('email', 'password'), $this->boolean('remember'))) {
                //     RateLimiter::hit($this->throttleKey());
                //     throw ValidationException::withMessages([
                //         'email' => trans('auth.failed'),
                //     ]);
                // }
                if (!$user || !Hash::check($this->password, $user->password)) {
                    // RateLimiter::hit($this->throttleKey());
                    throw ValidationException::withMessages([
                        'username' => trans('auth.failed'),
                    ]);
                }
                Auth::login($user, $this->boolean('remember'));
                RateLimiter::clear($this->throttleKey());

                break;

            case ($is_active->is_active === '0'):
                throw ValidationException::withMessages([
                    'username' => trans('auth.failed'),
                ]);
        }
    }

    /**
     * Ensure the login request is not rate limited.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function ensureIsNotRateLimited(): void
    {
        if (!RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout($this));

        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'email' => trans('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => ceil($seconds / 60),
            ]),
        ]);
    }

    /**
     * Get the rate limiting throttle key for the request.
     */
    public function throttleKey(): string
    {
        return Str::transliterate(Str::lower($this->input('email')) . '|' . $this->ip());
    }
}
