<textarea
    x-data
    x-init="new EasyMDE({ element: $el <?php echo e($jsonOptions()); ?> })"
    name="<?php echo e($name); ?>"
    id="<?php echo e($id); ?>"
    <?php echo e($attributes); ?>

><?php echo e(old($name, $slot)); ?></textarea>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/editors/easy-mde.blade.php ENDPATH**/ ?>