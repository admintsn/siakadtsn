<textarea
    name="<?php echo e($name); ?>"
    id="<?php echo e($id); ?>"
    rows="<?php echo e($rows); ?>"
    <?php echo e($attributes); ?>

><?php echo e(old($name, $slot)); ?></textarea>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/forms/inputs/textarea.blade.php ENDPATH**/ ?>