<div <?php echo e($attributes); ?>>
    <?php echo $toHtml($slot); ?>

</div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/markdown/markdown.blade.php ENDPATH**/ ?>