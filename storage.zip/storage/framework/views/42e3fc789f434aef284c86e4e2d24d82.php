<div
    <?php echo e($attributes->class([
            'fi-btn-group grid grid-flow-col rounded-lg shadow-sm ring-1 ring-gray-950/10 dark:ring-white/20',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/support/resources/views/components/button/group.blade.php ENDPATH**/ ?>