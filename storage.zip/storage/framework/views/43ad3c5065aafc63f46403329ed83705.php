<input
    name="<?php echo e($name); ?>"
    type="<?php echo e($type); ?>"
    id="<?php echo e($id); ?>"
    <?php if($value): ?>value="<?php echo e($value); ?>"<?php endif; ?>
    <?php echo e($attributes); ?>

/>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/forms/inputs/input.blade.php ENDPATH**/ ?>