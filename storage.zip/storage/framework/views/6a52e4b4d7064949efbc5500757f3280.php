<p
    data-validation-error
    <?php echo e($attributes->class([
            'fi-fo-field-wrp-error-message text-sm text-danger-600 dark:text-danger-400',
        ])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/forms/src/../resources/views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>