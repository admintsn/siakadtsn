<div
    <?php echo e($attributes->class(['fi-in-entry-wrp-helper-text text-sm text-gray-500'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/infolists/resources/views/components/entry-wrapper/helper-text.blade.php ENDPATH**/ ?>