<input
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
                'type' => 'hidden',
                $applyStateBindingModifiers('wire:model') => $getStatePath(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
            ->class(['fi-fo-hidden'])); ?>

/>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/forms/resources/views/components/hidden.blade.php ENDPATH**/ ?>