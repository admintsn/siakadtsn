<div>Number: <?php echo e($record->id); ?></div>
<div>Customer: <?php echo e($record->santri->nama_lengkap); ?></div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/resources/views/pdf.blade.php ENDPATH**/ ?>