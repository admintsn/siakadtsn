<div class="fi-ta-placeholder text-sm text-gray-400 dark:text-gray-500">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/tables/src/../resources/views/components/columns/placeholder.blade.php ENDPATH**/ ?>