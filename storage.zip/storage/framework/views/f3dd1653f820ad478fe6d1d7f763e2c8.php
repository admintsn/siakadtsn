<p
    <?php echo e($attributes->class(['fi-section-header-description overflow-hidden break-words text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/support/resources/views/components/section/description.blade.php ENDPATH**/ ?>