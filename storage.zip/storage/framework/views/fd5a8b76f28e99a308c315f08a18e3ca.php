<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/filament/support/src/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>