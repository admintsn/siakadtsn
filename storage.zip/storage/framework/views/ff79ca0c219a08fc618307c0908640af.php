<label for="<?php echo e($for); ?>" <?php echo e($attributes); ?>>
    <?php echo e($fallback); ?>

</label>
<?php /**PATH /home/u1571705/public_html/siakad.tsn.ponpes.id/vendor/blade-ui-kit/blade-ui-kit/resources/views/components/forms/label.blade.php ENDPATH**/ ?>